#!/usr/bin/env python3
"""Smoothly and safely bring the SO-101 robot arm back to its home parked stance on the desk."""

import sys
import time

try:
    import scservo_sdk as scs
except ImportError:
    print("scservo_sdk not found, please run with conda run -n lerobot python")
    sys.exit(1)

PORT = "/dev/ttyACM0"
BAUD = 1_000_000
TARGET_HOME = [2048, 900, 3100, 2800, 2048, 2050]
JOINT_NAMES = [
    "shoulder_pan",
    "shoulder_lift",
    "elbow_flex",
    "wrist_flex",
    "wrist_roll",
    "gripper",
]

port_handler = scs.PortHandler(PORT)
def _patch_set_packet_timeout(ph, packet_length):
    ph.packet_start_time = ph.getCurrentTime()
    ph.packet_timeout = (ph.tx_time_per_byte * packet_length) + (ph.tx_time_per_byte * 3.0) + 50
port_handler.setPacketTimeout = _patch_set_packet_timeout.__get__(port_handler, scs.PortHandler)
packet_handler = scs.PacketHandler(0)

if not port_handler.openPort():
    print(f"Failed to open port {PORT}")
    sys.exit(1)
if not port_handler.setBaudRate(BAUD):
    print(f"Failed to set baudrate {BAUD}")
    port_handler.closePort()
    sys.exit(1)

print(f"Connected to SO-101 on {PORT} at {BAUD} baud.")

# 1. Read current positions
current_pos = []
for m in range(1, 7):
    pos, comm, err = packet_handler.read2ByteTxRx(port_handler, m, 56)
    if comm != scs.COMM_SUCCESS:
        print(f"Error reading motor {m}: comm={comm}, err={err}")
        port_handler.closePort()
        sys.exit(1)
    current_pos.append(pos)
    print(f"  Motor {m} ({JOINT_NAMES[m-1]:<15}): current={pos} ticks -> target={TARGET_HOME[m-1]} ticks")

# 2. Lock current positions before enabling torque (prevents jump)
for m in range(1, 7):
    packet_handler.write2ByteTxRx(port_handler, m, 42, current_pos[m-1])
    time.sleep(0.005)
    packet_handler.write1ByteTxRx(port_handler, m, 40, 1)
    time.sleep(0.005)

print("\nTorque engaged smoothly at current positions. Moving gently to home...")

# 3. Smooth cosine interpolation over 3.0 seconds (60 Hz)
STEPS = 150  # 2.5 seconds at 60 Hz
for s in range(1, STEPS + 1):
    frac = s / STEPS
    # Smooth S-curve (cosine)
    alpha = 0.5 * (1.0 - (1.0 - frac * 2.0 if frac < 0.0 else (frac - 0.5) * 2.0))  # standard smoothstep
    import math
    smooth_frac = 0.5 * (1.0 - math.cos(frac * math.pi))
    
    for m in range(1, 7):
        target = int(current_pos[m-1] + smooth_frac * (TARGET_HOME[m-1] - current_pos[m-1]))
        packet_handler.write2ByteTxRx(port_handler, m, 42, target)
    time.sleep(0.02)
    
    if s % 30 == 0:
        pct = int(frac * 100)
        sys.stdout.write(f"\r  Homing progress: {pct}%...")
        sys.stdout.flush()

print("\n\nArrived at home stance.")
# Final check
for m in range(1, 7):
    final_p, _, _ = packet_handler.read2ByteTxRx(port_handler, m, 56)
    print(f"  Motor {m} ({JOINT_NAMES[m-1]:<15}): final={final_p} ticks")

# 4. Safely disable torque
for m in range(1, 7):
    packet_handler.write1ByteTxRx(port_handler, m, 40, 0)
    time.sleep(0.005)

port_handler.closePort()
print("\n[SUCCESS] Robot returned to home position. Torque safely disabled.")

