#!/usr/bin/env python3
"""Sim-to-Real Visual Comparison & RealSense Recording Tool.

Captures synchronized RGB frames from the physical RealSense D455 camera and
the Isaac Sim virtual camera, renders side-by-side comparison video with a
difference heatmap overlay, and computes SSIM, PSNR, and L1 visual similarity metrics.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import sys
import time
from pathlib import Path

import cv2
import numpy as np

ROOT_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT_DIR / "src"))

from isaac_vision_rl.utils.calibration import JOINT_ORDER
from isaac_vision_rl.utils.hardware_client import HardwareStreamer


def compute_metrics(real_bgr: np.ndarray, sim_bgr: np.ndarray) -> dict[str, float]:
    """Compute PSNR, MSE, MAE, and SSIM between real and simulated BGR frames."""
    diff = np.abs(real_bgr.astype(np.float32) - sim_bgr.astype(np.float32))
    mae = float(np.mean(diff))
    mse = float(np.mean(diff ** 2))
    psnr = 20.0 * math.log10(255.0 / math.sqrt(mse)) if mse > 1e-6 else 99.0

    # Fast SSIM calculation using OpenCV Gaussian blur
    gray1 = cv2.cvtColor(real_bgr, cv2.COLOR_BGR2GRAY).astype(np.float32)
    gray2 = cv2.cvtColor(sim_bgr, cv2.COLOR_BGR2GRAY).astype(np.float32)

    C1 = (0.01 * 255) ** 2
    C2 = (0.03 * 255) ** 2

    mu1 = cv2.GaussianBlur(gray1, (11, 11), 1.5)
    mu2 = cv2.GaussianBlur(gray2, (11, 11), 1.5)

    mu1_sq = mu1 ** 2
    mu2_sq = mu2 ** 2
    mu1_mu2 = mu1 * mu2

    sigma1_sq = cv2.GaussianBlur(gray1 ** 2, (11, 11), 1.5) - mu1_sq
    sigma2_sq = cv2.GaussianBlur(gray2 ** 2, (11, 11), 1.5) - mu2_sq
    sigma12 = cv2.GaussianBlur(gray1 * gray2, (11, 11), 1.5) - mu1_mu2

    ssim_map = ((2 * mu1_mu2 + C1) * (2 * sigma12 + C2)) / (
        (mu1_sq + mu2_sq + C1) * (sigma1_sq + sigma2_sq + C2)
    )
    ssim = float(np.mean(ssim_map))

    return {"ssim": ssim, "psnr": psnr, "mae": mae, "mse": mse}


def create_comparison_tile(
    real_bgr: np.ndarray, sim_bgr: np.ndarray, metrics: dict[str, float], frame_idx: int
) -> np.ndarray:
    """Create a 3-panel tile: [ Real Camera | Simulation Camera | Difference Heatmap ]."""
    h, w = real_bgr.shape[:2]

    # Generate difference heatmap
    diff = cv2.absdiff(real_bgr, sim_bgr)
    diff_gray = cv2.cvtColor(diff, cv2.COLOR_BGR2GRAY)
    heatmap = cv2.applyColorMap(diff_gray, cv2.COLORMAP_JET)

    # 50/50 visual alpha blend panel
    blend = cv2.addWeighted(real_bgr, 0.5, sim_bgr, 0.5, 0)

    # Label each subpanel
    def add_label(img: np.ndarray, text: str):
        canvas = img.copy()
        cv2.rectangle(canvas, (0, 0), (w, 24), (0, 0, 0), -1)
        cv2.putText(canvas, text, (6, 17), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1, cv2.LINE_AA)
        return canvas

    p1 = add_label(real_bgr, "RealSense D455 (Real)")
    p2 = add_label(sim_bgr, "Isaac Sim (Virtual)")
    p3 = add_label(heatmap, f"Heatmap | SSIM: {metrics['ssim']:.3f} PSNR: {metrics['psnr']:.1f}dB")

    tile = np.hstack([p1, p2, p3])
    return tile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seconds", type=float, default=16.0, help="Recording duration in seconds")
    parser.add_argument("--output-dir", default="outputs/comparison", help="Output directory for recordings and metrics")
    parser.add_argument("--device", default="cuda:0", help="Isaac Sim device")
    parser.add_argument("--viz", choices=["newton", "kit", "none"], default="none", help="Visualizer backend")
    parser.add_argument("--headless", action="store_true", help="Run without GUI preview window")
    parser.add_argument("--stream-to-robot", action="store_true", help="Also stream UDP motions to physical robot bridge")
    parser.add_argument(
        "--motion",
        choices=["reach-lift", "static"],
        default="reach-lift",
        help="Robot motion to execute during comparison: reach-lift (scripted pick & lift) or static",
    )
    parser.add_argument("--snapshot-only", action="store_true", help="Capture a single static frame alignment comparison and exit")
    args = parser.parse_args()

    os.environ["SO101_POLICY"] = "rgb"
    os.environ["SO101_CURRICULUM"] = "fixed"
    os.environ["SO101_CUBE_JITTER"] = "0.0"
    os.environ["SO101_BOX_JITTER"] = "0.0"

    out_dir = Path(args.output_dir).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    # 1. Initialize RealSense Camera
    import pyrealsense2 as rs

    print("[INFO] Initializing RealSense D455 Camera (424x240 @ 60 FPS)...")
    pipe = rs.pipeline()
    cfg_rs = rs.config()
    cfg_rs.enable_stream(rs.stream.color, 424, 240, rs.format.bgr8, 60)

    try:
        profile = pipe.start(cfg_rs)
    except Exception as e:
        print(f"[ERROR] Failed to start RealSense camera: {e}")
        print("        Ensure camera is plugged into a USB 3.0 port and no other script is using it.")
        sys.exit(1)

    print("[SUCCESS] RealSense camera streaming active.")

    # 2. Launch Isaac Sim Environment
    import gymnasium as gym
    import torch
    from isaaclab.app import launch_simulation
    from isaac_vision_rl.tasks.pickplace.config.so101.env_cfg import PickLiftEnvCfg
    from isaac_vision_rl.utils.grasp_geometry import ARM_NAMES, GraspGeometry

    cfg_sim = PickLiftEnvCfg()
    cfg_sim.scene.num_envs = 1
    cfg_sim.sim.device = args.device
    cfg_sim.scene.camera.width = 424
    cfg_sim.scene.camera.height = 240

    streamer = None
    if args.stream_to_robot:
        streamer = HardwareStreamer(joint_names=JOINT_ORDER, target_rate_hz=60.0)

    viz_choice = None if args.headless or args.viz == "none" else args.viz

    print("[INFO] Launching Isaac Sim environment...")
    with launch_simulation(cfg_sim, {"device": args.device, "visualizer": viz_choice}):
        env = gym.make("IsaacVisionRl-PickLift-SO101", cfg=cfg_sim)
        try:
            env.reset()
            base = env.unwrapped
            robot = base.scene["robot"]
            sim_camera = base.scene["camera"]

            joint_indices = [robot.find_joints(name)[0][0] for name in JOINT_ORDER]

            # Warm-up cameras
            print("[INFO] Warming up camera sensors...")
            for _ in range(15):
                pipe.wait_for_frames(2000)
                base.sim.render()
                sim_camera.update(cfg_sim.sim.dt, force_recompute=True)

            if args.snapshot_only:
                print("[INFO] Capturing static pose alignment snapshot...")
                fs = pipe.wait_for_frames(2000)
                real_frame = np.asanyarray(fs.get_color_frame().get_data())

                base.sim.render()
                sim_rgb_out = sim_camera.data.output["rgb"]
                sim_rgb = sim_rgb_out.torch[0, :, :, :3] if hasattr(sim_rgb_out, "torch") else sim_rgb_out[0, :, :, :3]
                sim_bgr = cv2.cvtColor(sim_rgb.cpu().numpy().astype(np.uint8), cv2.COLOR_RGB2BGR)

                metrics = compute_metrics(real_frame, sim_bgr)
                tile = create_comparison_tile(real_frame, sim_bgr, metrics, 0)

                snap_path = out_dir / "sim_vs_real_snapshot.png"
                cv2.imwrite(str(snap_path), tile)

                report_path = out_dir / "static_similarity_report.json"
                report_path.write_text(json.dumps(metrics, indent=2) + "\n")

                print(f"[SUCCESS] Snapshot saved to: {snap_path}")
                print(f"[METRICS] SSIM: {metrics['ssim']:.4f} | PSNR: {metrics['psnr']:.2f} dB | MAE: {metrics['mae']:.2f}")
                return

            # Setup video writers
            fourcc = cv2.VideoWriter.fourcc(*"mp4v")
            fps = 60.0
            video_side_by_side = cv2.VideoWriter(str(out_dir / "sim_vs_real_comparison.mp4"), fourcc, fps, (424 * 3, 240))
            video_real = cv2.VideoWriter(str(out_dir / "real_footage.mp4"), fourcc, fps, (424, 240))
            video_sim = cv2.VideoWriter(str(out_dir / "sim_footage.mp4"), fourcc, fps, (424, 240))

            # Build motion trajectory if reach-lift is requested
            trajectory_targets = []
            if args.motion == "reach-lift":
                spawner = cfg_sim.scene.robot.spawn
                geometry = GraspGeometry(spawner.usd_path, cfg_sim.scene.robot.init_state.pos, cfg_sim.scene.robot.init_state.rot)
                cube_pos = np.array(cfg_sim.scene.cube.init_state.pos)

                home_arm = [cfg_sim.scene.robot.init_state.joint_pos[n] for n in ARM_NAMES]
                above_arm = geometry.solve(cube_pos + [0, 0, 0.05], home_arm).tolist()
                grasp_arm = geometry.solve(cube_pos, above_arm).tolist()
                lift_arm = geometry.solve(cube_pos + [0, 0, 0.08], grasp_arm).tolist()

                pose_home = home_arm + [0.0]
                pose_above = above_arm + [1.2]
                pose_grasp_open = grasp_arm + [1.2]
                pose_grasp_closed = grasp_arm + [0.0]
                pose_lifted = lift_arm + [0.0]

                segments = [
                    (pose_home, pose_above, 3.0),
                    (pose_above, pose_grasp_open, 2.0),
                    (pose_grasp_open, pose_grasp_closed, 1.5),
                    (pose_grasp_closed, pose_lifted, 2.5),
                    (pose_lifted, pose_grasp_closed, 2.0),
                    (pose_grasp_closed, pose_grasp_open, 1.5),
                    (pose_grasp_open, pose_above, 1.5),
                    (pose_above, pose_home, 2.0),
                ]
                for p_start, p_end, dur in segments:
                    n_steps = max(1, int(dur * fps))
                    for s in range(n_steps):
                        frac = (s + 1) / n_steps
                        alpha = 0.5 * (1.0 - math.cos(frac * math.pi))
                        interp_q = [(1.0 - alpha) * a + alpha * b for a, b in zip(p_start, p_end)]
                        trajectory_targets.append(interp_q)

            print(f"[INFO] Beginning recording for {args.seconds:.1f} seconds at 60 Hz (motion={args.motion})...")
            total_frames = int(args.seconds * fps)
            all_metrics = []

            for frame_idx in range(total_frames):
                # 1. Fetch real camera frame
                fs = pipe.wait_for_frames(2000)
                real_bgr = np.asanyarray(fs.get_color_frame().get_data())

                # 2. Step Isaac Sim & render virtual camera
                if trajectory_targets:
                    target_q = trajectory_targets[frame_idx % len(trajectory_targets)]
                    q_tensor = robot.data.joint_pos.torch.clone()
                    q_tensor[0, joint_indices] = torch.tensor(target_q, device=args.device, dtype=torch.float32)
                    robot.set_joint_position_target(q_tensor)

                for physics_step in range(cfg_sim.decimation):
                    base.scene.write_data_to_sim()
                    base.sim.step(render=physics_step == cfg_sim.decimation - 1)
                    base.scene.update(cfg_sim.sim.dt)
                sim_camera.update(cfg_sim.sim.dt, force_recompute=True)

                sim_rgb_out = sim_camera.data.output["rgb"]
                sim_rgb = sim_rgb_out.torch[0, :, :, :3] if hasattr(sim_rgb_out, "torch") else sim_rgb_out[0, :, :, :3]
                sim_bgr = cv2.cvtColor(sim_rgb.cpu().numpy().astype(np.uint8), cv2.COLOR_RGB2BGR)

                # Optional: stream to real robot
                if streamer is not None:
                    joint_pos_t = robot.data.joint_pos.torch[0, joint_indices]
                    streamer.send_joint_targets(joint_pos_t.cpu().numpy().tolist())
                    streamer.pace(base.step_dt)

                # 3. Compute metrics & composite tile
                m = compute_metrics(real_bgr, sim_bgr)
                all_metrics.append(m)

                tile = create_comparison_tile(real_bgr, sim_bgr, m, frame_idx)

                # 4. Write to video files
                video_side_by_side.write(tile)
                video_real.write(real_bgr)
                video_sim.write(sim_bgr)

                if not args.headless:
                    cv2.imshow("Real vs Simulation Real-Time Comparison", tile)
                    if cv2.waitKey(1) & 0xFF == ord("q"):
                        print("\n[INFO] Stopped early by user.")
                        break

                if (frame_idx + 1) % 60 == 0 or frame_idx == total_frames - 1:
                    sys.stdout.write(
                        f"\r[REC] Frame {frame_idx + 1}/{total_frames} | "
                        f"SSIM: {m['ssim']:.3f} | PSNR: {m['psnr']:.1f} dB | MAE: {m['mae']:.1f}   "
                    )
                    sys.stdout.flush()

            print("\n[INFO] Finalizing video files...")
            video_side_by_side.release()
            video_real.release()
            video_sim.release()
            if not args.headless:
                cv2.destroyAllWindows()

            # Save summary report
            avg_ssim = float(np.mean([x["ssim"] for x in all_metrics]))
            avg_psnr = float(np.mean([x["psnr"] for x in all_metrics]))
            avg_mae = float(np.mean([x["mae"] for x in all_metrics]))

            summary = {
                "total_frames": len(all_metrics),
                "duration_s": len(all_metrics) / fps,
                "average_ssim": avg_ssim,
                "average_psnr_db": avg_psnr,
                "average_mae": avg_mae,
                "comparison_video": str(out_dir / "sim_vs_real_comparison.mp4"),
                "real_video": str(out_dir / "real_footage.mp4"),
                "sim_video": str(out_dir / "sim_footage.mp4"),
            }
            report_file = out_dir / "similarity_report.json"
            report_file.write_text(json.dumps(summary, indent=2) + "\n")

            print("\n" + "=" * 70)
            print("SIM-TO-REAL VISUAL SIMILARITY REPORT")
            print("=" * 70)
            print(f"Recorded frames:    {summary['total_frames']} ({summary['duration_s']:.1f}s)")
            print(f"Average SSIM:       {summary['average_ssim']:.4f}  (Structural Similarity 0..1)")
            print(f"Average PSNR:       {summary['average_psnr_db']:.2f} dB (Peak Signal-to-Noise)")
            print(f"Average Pixel MAE:  {summary['average_mae']:.2f} / 255")
            print(f"Comparison Video:   {summary['comparison_video']}")
            print("=" * 70)

        finally:
            pipe.stop()
            if streamer is not None:
                streamer.close()
            env.close()


if __name__ == "__main__":
    main()
