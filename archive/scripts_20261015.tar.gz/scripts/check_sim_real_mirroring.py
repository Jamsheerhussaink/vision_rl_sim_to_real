#!/usr/bin/env python3
"""Sim-to-Real Mirroring Diagnostic & Disparity Verification Tool.

Publishes identical test motions to both Isaac Sim and the physical SO-101 robot,
records real-time tracking from both domains, compares joint movements, detects
faults (stalls, direction inversions, torque limits, voltage drops, lag), and
generates a comprehensive diagnostic report pinpointing which joints have problems.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Sequence

import numpy as np

# Add src to path
ROOT_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT_DIR / "src"))

# Try importing scservo_sdk; fallback to lerobot environment path if running in env_isaaclab
try:
    import scservo_sdk as scs
except ImportError:
    lerobot_pkg = Path("/home/ai/miniconda3/envs/lerobot/lib/python3.12/site-packages")
    if lerobot_pkg.exists() and str(lerobot_pkg) not in sys.path:
        sys.path.append(str(lerobot_pkg))
    try:
        import scservo_sdk as scs
    except ImportError:
        scs = None

from isaac_vision_rl.utils.calibration import (
    CALIB_FILE_PATH,
    JOINT_ORDER,
    SIM_GRIPPER_MAX_RAD,
    FollowerArmCalibration,
)

# Standard home pose in simulation (radians)
DEFAULT_HOME_RAD = np.array([0.00359878, -1.25, 1.60, 0.45, 0.0, 0.0], dtype=np.float64)


def cosine_interpolate(start_q: np.ndarray, end_q: np.ndarray, frac: float) -> np.ndarray:
    """Cosine ease-in / ease-out smooth interpolation between two joint poses."""
    alpha = 0.5 * (1.0 - math.cos(frac * math.pi))
    return (1.0 - alpha) * start_q + alpha * end_q


class BaseHardwareInterface:
    def connect(self) -> None:
        raise NotImplementedError

    def enable_torque(self, allow_holding: bool = True) -> list[int]:
        raise NotImplementedError

    def read_positions(self) -> list[int] | None:
        raise NotImplementedError

    def read_diagnostics(self, motor_id: int) -> dict[str, Any]:
        raise NotImplementedError

    def sync_write_positions(self, goal_ticks: list[int]) -> bool:
        raise NotImplementedError

    def disable_torque(self) -> None:
        raise NotImplementedError

    def close(self) -> None:
        raise NotImplementedError


class MockHardwareInterface(BaseHardwareInterface):
    """Simulates real hardware responses with optional simulated lag/voltage for testing."""

    def __init__(self, calib: FollowerArmCalibration):
        self.calib = calib
        self.current_ticks = calib.rad_to_ticks(DEFAULT_HOME_RAD)
        self.connected = True
        self.torque_enabled = False

    def connect(self) -> None:
        self.connected = True

    def enable_torque(self, allow_holding: bool = True) -> list[int]:
        self.torque_enabled = True
        return list(self.current_ticks)

    def read_positions(self) -> list[int]:
        return list(self.current_ticks)

    def read_diagnostics(self, motor_id: int) -> dict[str, Any]:
        return {"voltage": 7.4, "load": 50, "error": 0, "torque": int(self.torque_enabled)}

    def sync_write_positions(self, goal_ticks: list[int]) -> bool:
        # Move smoothly towards target
        for i in range(6):
            delta = goal_ticks[i] - self.current_ticks[i]
            step = int(np.clip(delta, -80, 80))
            self.current_ticks[i] += step
        return True

    def disable_torque(self) -> None:
        self.torque_enabled = False

    def close(self) -> None:
        self.connected = False


class FeetechBusInterface(BaseHardwareInterface):
    """Direct serial connection to Feetech STS3215 servos on SO-101 arm."""

    def __init__(self, port: str, baud: int, calib: FollowerArmCalibration):
        if scs is None:
            raise ImportError(
                "scservo_sdk is not available. Please install it or point to the 'lerobot' environment."
            )
        self.port = port
        self.baud = baud
        self.calib = calib
        self.port_handler = scs.PortHandler(port)
        self.packet_handler = scs.PacketHandler(0)
        self.sync_writer = None
        self.connected = False

    def connect(self) -> None:
        if not self.port_handler.openPort():
            raise IOError(f"Failed to open serial port {self.port}. Check permissions or USB connection.")
        if not self.port_handler.setBaudRate(self.baud):
            raise IOError(f"Failed to set baudrate {self.baud} on {self.port}")

        # STS3215 Goal_Position register: 42, length 2 bytes
        self.sync_writer = scs.GroupSyncWrite(self.port_handler, self.packet_handler, 42, 2)
        self.connected = True

    def _read_byte(self, motor_id: int, address: int) -> int:
        val, comm, err = self.packet_handler.read1ByteTxRx(self.port_handler, motor_id, address)
        if comm != scs.COMM_SUCCESS or err:
            return 0
        return val

    def _read_word(self, motor_id: int, address: int) -> int:
        val, comm, err = self.packet_handler.read2ByteTxRx(self.port_handler, motor_id, address)
        if comm != scs.COMM_SUCCESS or err:
            return 0
        return val

    def read_positions(self) -> list[int] | None:
        if not self.connected:
            return None
        positions = []
        for motor_id in self.calib.servo_ids:
            val, comm, err = self.packet_handler.read2ByteTxRx(self.port_handler, motor_id, 56)
            if comm != scs.COMM_SUCCESS or err:
                return None
            positions.append(val)
        return positions

    def read_diagnostics(self, motor_id: int) -> dict[str, Any]:
        if not self.connected:
            return {"voltage": 0.0, "load": 0, "error": -1, "torque": 0}
        volt_raw = self._read_byte(motor_id, 62)
        load = self._read_word(motor_id, 60)
        err = self._read_byte(motor_id, 65)
        torque = self._read_byte(motor_id, 40)
        return {
            "voltage": float(volt_raw) / 10.0,
            "load": int(load),
            "error": int(err),
            "torque": int(torque),
        }

    def enable_torque(self, allow_holding: bool = True) -> list[int]:
        if not self.connected:
            raise IOError("Motor bus not connected")
        current_pos = self.read_positions()
        if current_pos is None:
            raise RuntimeError("Failed to read initial positions from all 6 motors")

        # Seed current measured positions as holding targets
        for motor_id, pos in zip(self.calib.servo_ids, current_pos):
            self.packet_handler.write2ByteTxRx(self.port_handler, motor_id, 42, pos)

        # Enable torque on all servos
        for motor_id in self.calib.servo_ids:
            self.packet_handler.write1ByteTxRx(self.port_handler, motor_id, 40, 1)

        time.sleep(0.05)
        return current_pos

    def sync_write_positions(self, goal_ticks: list[int]) -> bool:
        if not self.connected or self.sync_writer is None:
            return False
        self.sync_writer.clearParam()
        for motor_id, ticks in zip(self.calib.servo_ids, goal_ticks):
            param = [scs.SCS_LOBYTE(ticks), scs.SCS_HIBYTE(ticks)]
            if not self.sync_writer.addParam(motor_id, param):
                return False
        comm = self.sync_writer.txPacket()
        return comm == scs.COMM_SUCCESS

    def disable_torque(self) -> None:
        if self.connected:
            for motor_id in self.calib.servo_ids:
                try:
                    self.packet_handler.write1ByteTxRx(self.port_handler, motor_id, 40, 0)
                except Exception:
                    pass

    def close(self) -> None:
        if self.connected:
            self.disable_torque()
            self.port_handler.closePort()
            self.connected = False


class KinematicSim:
    """Instantaneous kinematic digital twin for fast zero-delay verification."""

    def __init__(self, calib: FollowerArmCalibration):
        self.calib = calib
        self.current_rad = DEFAULT_HOME_RAD.copy()

    def reset(self) -> np.ndarray:
        self.current_rad = DEFAULT_HOME_RAD.copy()
        return self.current_rad.copy()

    def step(self, target_rad: np.ndarray) -> np.ndarray:
        # Kinematic model tracks targets clamped to limits
        lower, upper = self.calib.get_joint_limits_rad()
        clamped = np.clip(target_rad, lower, upper)
        # Slew rate of 1.5 rad/s over 1/60s dt = 0.025 rad/step
        max_step = 0.03
        delta = clamped - self.current_rad
        step_delta = np.clip(delta, -max_step, max_step)
        self.current_rad += step_delta
        return self.current_rad.copy()

    def close(self) -> None:
        pass


class IsaacLabSim:
    """Full PhysX-based Isaac Lab simulation environment."""

    def __init__(self, device: str = "cuda:0", viz: str = "newton"):
        os.environ["SO101_POLICY"] = "rgb"
        os.environ["SO101_CURRICULUM"] = "fixed"
        os.environ["SO101_CUBE_JITTER"] = "0.0"
        os.environ["SO101_BOX_JITTER"] = "0.0"

        import gymnasium as gym
        import torch
        from isaaclab.app import launch_simulation
        from isaac_vision_rl.tasks.pickplace.config.so101.env_cfg import PickLiftEnvCfg

        self.torch = torch
        self.device = device
        self.cfg = PickLiftEnvCfg()
        self.cfg.scene.num_envs = 1
        self.cfg.sim.device = device

        viz_backend = None if viz == "none" else viz
        self.ctx = launch_simulation(self.cfg, {"device": device, "visualizer": viz_backend})
        self.ctx.__enter__()
        self.env = gym.make("IsaacVisionRl-PickLift-SO101", cfg=self.cfg)
        self.env.reset()
        self.base = self.env.unwrapped
        self.robot = self.base.scene["robot"]
        self.joint_indices = [self.robot.find_joints(name)[0][0] for name in JOINT_ORDER]

    def reset(self) -> np.ndarray:
        self.env.reset()
        return self._get_pos()

    def _get_pos(self) -> np.ndarray:
        joint_pos_t = self.robot.data.joint_pos.torch[0, self.joint_indices]
        return joint_pos_t.cpu().numpy()

    def step(self, target_rad: np.ndarray) -> np.ndarray:
        q_tensor = self.robot.data.joint_pos.torch.clone()
        q_tensor[0, self.joint_indices] = self.torch.tensor(target_rad, device=self.device, dtype=self.torch.float32)
        try:
            self.robot.actuators.target_command.set_position_index(value=q_tensor)
        except Exception:
            self.robot.set_joint_position_target(q_tensor)
        for physics_step in range(self.cfg.decimation):
            self.base.scene.write_data_to_sim()
            self.base.sim.step(render=physics_step == self.cfg.decimation - 1)
            self.base.scene.update(self.cfg.sim.dt)
        return self._get_pos()

    def close(self) -> None:
        try:
            self.env.close()
        except Exception:
            pass
        if hasattr(self, "ctx"):
            try:
                self.ctx.__exit__(None, None, None)
            except Exception:
                pass



def generate_single_joint_sweep_targets(calib: FollowerArmCalibration) -> list[tuple[str, np.ndarray, str]]:
    """Generates isolated safe perturbations for each individual joint."""
    home = DEFAULT_HOME_RAD.copy()
    sweeps = []

    # 1. shoulder_pan (+8 deg then -8 deg)
    p1 = home.copy()
    p1[0] += np.deg2rad(8.0)
    sweeps.append(("shoulder_pan", p1, "Pan +8° (CCW / Left)"))

    # 2. shoulder_lift (-6 deg upward pitch)
    p2 = home.copy()
    p2[1] -= np.deg2rad(6.0)
    sweeps.append(("shoulder_lift", p2, "Shoulder Lift -6° (Pitch Up away from table)"))

    # 3. elbow_flex (+8 deg bend)
    p3 = home.copy()
    p3[2] += np.deg2rad(8.0)
    sweeps.append(("elbow_flex", p3, "Elbow Flex +8° (Bend Elbow)"))

    # 4. wrist_flex (-8 deg pitch up)
    p4 = home.copy()
    p4[3] -= np.deg2rad(8.0)
    sweeps.append(("wrist_flex", p4, "Wrist Flex -8° (Pitch Wrist)"))

    # 5. wrist_roll (+15 deg roll)
    p5 = home.copy()
    p5[4] += np.deg2rad(15.0)
    sweeps.append(("wrist_roll", p5, "Wrist Roll +15° (Roll Wrist)"))

    # 6. gripper (+0.6 rad open, then close)
    p6 = home.copy()
    p6[5] = 0.60
    sweeps.append(("gripper", p6, "Gripper Open to 0.6 rad (~35°)"))

    return sweeps


def generate_safe_random_waypoints(num_waypoints: int = 3, seed: int = 42) -> list[np.ndarray]:
    """Generates random coordinated poses strictly bounded within a collision-free safe envelope."""
    rng = np.random.default_rng(seed)
    home = DEFAULT_HOME_RAD.copy()
    waypoints = [home.copy()]

    for _ in range(num_waypoints):
        w = home.copy()
        # Safe random deltas around home (radians)
        w[0] += rng.uniform(-np.deg2rad(10), np.deg2rad(10))   # pan: +/- 10 deg
        w[1] += rng.uniform(-np.deg2rad(8), np.deg2rad(4))     # lift: -8 deg (up) to +4 deg (down)
        w[2] += rng.uniform(-np.deg2rad(10), np.deg2rad(10))   # elbow: +/- 10 deg
        w[3] += rng.uniform(-np.deg2rad(8), np.deg2rad(8))     # wrist_flex: +/- 8 deg
        w[4] += rng.uniform(-np.deg2rad(20), np.deg2rad(20))   # wrist_roll: +/- 20 deg
        w[5] = rng.uniform(0.10, 0.90)                         # gripper: 0.1 to 0.9 rad
        waypoints.append(w)

    waypoints.append(home.copy())  # return home at end
    return waypoints


def run_mirroring_verification(
    hardware: BaseHardwareInterface,
    sim: Any,
    calib: FollowerArmCalibration,
    test_mode: str = "all",
    num_random: int = 3,
    step_duration_s: float = 2.0,
    rate_hz: float = 30.0,
) -> dict[str, Any]:
    """Executes identical commands across sim and hardware, logs tracking, and evaluates discrepancies."""
    dt = 1.0 / rate_hz
    total_steps_per_segment = max(10, int(step_duration_s * rate_hz))

    print("\n" + "=" * 80)
    print("STARTING SIM-TO-REAL MOTION MIRRORING DIAGNOSTIC")
    print("=" * 80)
    print(f"Update Rate:     {rate_hz:.1f} Hz (dt={dt*1000:.1f} ms)")
    print(f"Segment Time:    {step_duration_s:.1f} s ({total_steps_per_segment} steps)")
    print(f"Test Mode:       {test_mode}")
    print("=" * 80 + "\n")

    # Initial position read
    real_ticks = hardware.read_positions()
    if real_ticks is None:
        raise RuntimeError("Could not read initial positions from hardware!")

    real_init_rad = calib.ticks_to_rad(real_ticks)
    sim_init_rad = sim.reset()

    print("Initial Positions Check:")
    for i, name in enumerate(JOINT_ORDER):
        print(
            f"  {name:<15}: Sim = {np.rad2deg(sim_init_rad[i]):>6.1f}° | "
            f"Real = {np.rad2deg(real_init_rad[i]):>6.1f}° ({real_ticks[i]} ticks)"
        )
    print("-" * 80)

    # Compile motion segments
    segments: list[tuple[str, np.ndarray, np.ndarray, str]] = []

    # Phase 1: Isolated Sweeps
    if test_mode in ("all", "sweep"):
        sweeps = generate_single_joint_sweep_targets(calib)
        curr_pose = DEFAULT_HOME_RAD.copy()
        for joint, target_pose, desc in sweeps:
            segments.append((f"Sweep: {joint}", curr_pose.copy(), target_pose.copy(), desc))
            segments.append((f"Return: {joint}", target_pose.copy(), curr_pose.copy(), f"Return {joint} to Home"))

    # Phase 2: Multi-Joint Random Waypoints
    if test_mode in ("all", "random"):
        random_wps = generate_safe_random_waypoints(num_random)
        for i in range(len(random_wps) - 1):
            start_p = random_wps[i]
            end_p = random_wps[i + 1]
            segments.append((
                f"Random WP {i + 1}/{len(random_wps) - 1}",
                start_p,
                end_p,
                f"Multi-joint interpolation to Waypoint {i + 1}",
            ))

    records: list[dict[str, Any]] = []
    start_time = time.time()

    for seg_idx, (seg_name, start_q, end_q, desc) in enumerate(segments):
        print(f"\n[{seg_idx + 1}/{len(segments)}] Executing {seg_name}: {desc}...")

        for step in range(total_steps_per_segment):
            step_start = time.perf_counter()
            frac = (step + 1) / total_steps_per_segment
            cmd_q = cosine_interpolate(start_q, end_q, frac)

            # 1. Step Simulation
            sim_q = sim.step(cmd_q)

            # 2. Step Real Hardware
            goal_ticks = calib.rad_to_ticks(cmd_q)
            hardware.sync_write_positions(list(goal_ticks))

            # 3. Read Real Hardware Feedback
            current_real_ticks = hardware.read_positions()
            if current_real_ticks is not None:
                real_q = calib.ticks_to_rad(current_real_ticks)
            else:
                real_q = real_init_rad.copy()
                current_real_ticks = list(calib.rad_to_ticks(real_q))

            elapsed = time.time() - start_time
            record = {
                "time_s": elapsed,
                "segment": seg_name,
                "cmd_rad": cmd_q.tolist(),
                "sim_rad": sim_q.tolist(),
                "real_rad": real_q.tolist(),
                "real_ticks": [int(t) for t in current_real_ticks],
                "error_deg": (np.rad2deg(real_q - sim_q)).tolist(),
            }
            records.append(record)

            # Real-time console update
            if step % 5 == 0 or step == total_steps_per_segment - 1:
                max_err_deg = np.max(np.abs(np.rad2deg(real_q - sim_q)))
                sys.stdout.write(
                    f"\r  Progress: {int(frac * 100):>3d}% | Sim-Real Max Disparity: {max_err_deg:4.1f}°   "
                )
                sys.stdout.flush()

            # Pacing
            calc_time = time.perf_counter() - step_start
            sleep_time = max(0.0, dt - calc_time)
            time.sleep(sleep_time)

        print()

    # Read final diagnostic registers for each motor
    diagnostics = {}
    for motor_id in calib.servo_ids:
        diagnostics[motor_id] = hardware.read_diagnostics(motor_id)

    return {
        "records": records,
        "diagnostics": diagnostics,
        "segments": [s[0] for s in segments],
        "calib": calib,
    }


def analyze_and_diagnose(data: dict[str, Any]) -> dict[str, Any]:
    """Analyzes motion traces, pinpoints faulty joints, identifies root causes, and creates summary table."""
    records = data["records"]
    diagnostics = data["diagnostics"]
    calib: FollowerArmCalibration = data["calib"]

    cmd_arr = np.array([r["cmd_rad"] for r in records])
    sim_arr = np.array([r["sim_rad"] for r in records])
    real_arr = np.array([r["real_rad"] for r in records])

    # Convert to degrees for human readability
    cmd_deg = np.rad2deg(cmd_arr)
    sim_deg = np.rad2deg(sim_arr)
    real_deg = np.rad2deg(real_arr)

    report_joints: dict[str, Any] = {}

    for i, joint in enumerate(JOINT_ORDER):
        motor_id = calib.servo_ids[i]
        diag = diagnostics.get(motor_id, {"voltage": 0.0, "load": 0, "error": 0})

        # Disparity metrics (Sim vs Real)
        disparity = real_deg[:, i] - sim_deg[:, i]
        abs_disparity = np.abs(disparity)
        mae = float(np.mean(abs_disparity))
        max_err = float(np.max(abs_disparity))
        rms_err = float(np.sqrt(np.mean(disparity ** 2)))

        # Movement spans
        sim_span = float(np.ptp(sim_deg[:, i]))
        real_span = float(np.ptp(real_deg[:, i]))
        cmd_span = float(np.ptp(cmd_deg[:, i]))

        # Direction correlation
        delta_sim = np.diff(sim_deg[:, i])
        delta_real = np.diff(real_deg[:, i])
        active_mask = np.abs(delta_sim) > 0.10  # Only evaluate when sim actually moved
        if np.any(active_mask):
            signs_match = np.sign(delta_sim[active_mask]) == np.sign(delta_real[active_mask])
            dir_match_pct = float(np.mean(signs_match) * 100.0)
        else:
            dir_match_pct = 100.0

        # Fault Diagnosis Logic
        problems = []
        status = "PASS"

        # Check 1: Stall / Dead motor
        if cmd_span > 4.0 and real_span < 1.0:
            status = "FAIL"
            if diag["voltage"] < 5.8:
                problems.append(
                    f"STALL (Insufficient Voltage: {diag['voltage']:.1f}V). Servos need 7.4V DC external power; USB 5V cannot supply enough torque."
                )
            else:
                problems.append("STALL: Motor is receiving commands but did not move physically.")

        # Check 2: Direction Mismatch (Inverted sign)
        elif cmd_span > 4.0 and dir_match_pct < 40.0:
            status = "FAIL"
            problems.append(
                f"DIRECTION INVERSION: Real motor rotated opposite to simulation (Direction match: {dir_match_pct:.0f}%). "
                f"Need to toggle drive_mode (0 <-> 1) in my_awesome_follower_arm.json."
            )

        # Check 3: Large Steady-state Lag / Gravity Sag
        elif mae > 6.0:
            status = "WARN" if max_err < 12.0 else "FAIL"
            if joint == "shoulder_lift":
                problems.append(
                    f"GRAVITY SAG: Persistent tracking error (MAE={mae:.1f}°, Max={max_err:.1f}°). "
                    "Arm is deflecting under gravitational load."
                )
            else:
                problems.append(f"HIGH TRACKING LAG (MAE={mae:.1f}°, Max={max_err:.1f}°).")

        # Check 4: Minor Lag
        elif mae > 3.0:
            status = "WARN"
            problems.append(f"Minor tracking discrepancy (MAE={mae:.1f}°).")

        # Check 5: Hardware error register flags
        if diag.get("error", 0) != 0:
            status = "FAIL"
            problems.append(f"Hardware Error Code {diag['error']} in register 65 (Overload/Overheat).")

        if not problems:
            problems.append("Movement mirrored accurately within tolerances.")

        report_joints[joint] = {
            "motor_id": motor_id,
            "status": status,
            "sim_span_deg": sim_span,
            "real_span_deg": real_span,
            "cmd_span_deg": cmd_span,
            "mae_deg": mae,
            "max_err_deg": max_err,
            "rms_err_deg": rms_err,
            "dir_match_pct": dir_match_pct,
            "voltage": diag["voltage"],
            "load": diag["load"],
            "error_reg": diag["error"],
            "diagnoses": problems,
        }

    return report_joints


def print_diagnostic_report(report_joints: dict[str, Any]) -> None:
    """Prints a formatted ASCII report highlighting faulty joints and solutions."""
    print("\n" + "=" * 105)
    print("SIM-TO-REAL MOTOR MIRRORING DIAGNOSTIC REPORT")
    print("=" * 105)
    print(
        f"{'Joint':<15} {'ID':<4} {'Status':<10} {'Sim Δ':<9} {'Real Δ':<9} "
        f"{'MAE':<8} {'Max Err':<9} {'Dir Match':<11} {'Volt':<6} {'Load'}"
    )
    print("-" * 105)

    for joint, d in report_joints.items():
        status_str = f"[{d['status']}]"
        print(
            f"{joint:<15} {d['motor_id']:<4} {status_str:<10} "
            f"{d['sim_span_deg']:>6.1f}°  {d['real_span_deg']:>6.1f}°  "
            f"{d['mae_deg']:>5.1f}°  {d['max_err_deg']:>6.1f}°   "
            f"{d['dir_match_pct']:>5.0f}%     "
            f"{d['voltage']:>4.1f}V {d['load']:>5d}"
        )

    print("=" * 105)
    print("\nIDENTIFIED PROBLEMS & RECOMMENDED FIXES:")
    print("-" * 105)

    any_fail = False
    for joint, d in report_joints.items():
        if d["status"] != "PASS":
            any_fail = True
            print(f"❌ Joint: {joint} (Motor ID {d['motor_id']}) -> Status: {d['status']}")
            for p in d["diagnoses"]:
                print(f"   • {p}")
            print()

    if not any_fail:
        print("✅ ALL JOINTS PASSED: Simulation and physical hardware mirrored accurately!")

    print("-" * 105 + "\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", default="/dev/ttyACM0", help="Serial port for Feetech servos")
    parser.add_argument("--baud", type=int, default=1_000_000, help="Serial baud rate")
    parser.add_argument("--sim", choices=["isaaclab", "kinematic"], default="kinematic", help="Simulation backend")
    parser.add_argument("--viz", choices=["newton", "kit", "none"], default="none", help="Visualizer for Isaac Lab")
    parser.add_argument("--device", default="cuda:0", help="Simulation device")
    parser.add_argument("--mock", action="store_true", help="Run with mock hardware (dry run)")
    parser.add_argument("--mode", choices=["all", "sweep", "random"], default="all", help="Test mode")
    parser.add_argument("--waypoints", type=int, default=3, help="Number of random waypoints")
    parser.add_argument("--step-time", type=float, default=2.0, help="Duration per movement segment in seconds")
    parser.add_argument("--output-dir", default=str(ROOT_DIR / "outputs/hardware_mapping"), help="Output directory")
    args = parser.parse_args()

    calib = FollowerArmCalibration(CALIB_FILE_PATH)

    # Initialize Hardware
    if args.mock:
        print("[INFO] Initializing MOCK hardware interface...")
        hardware = MockHardwareInterface(calib)
    else:
        print(f"[INFO] Connecting to Feetech servo bus on {args.port} ({args.baud} baud)...")
        hardware = FeetechBusInterface(args.port, args.baud, calib)

    hardware.connect()
    try:
        print("[INFO] Enabling servo torque at holding targets...")
        hardware.enable_torque(allow_holding=True)

        # Initialize Simulation
        if args.sim == "isaaclab":
            print(f"[INFO] Launching Isaac Lab ({args.viz} viewer on {args.device})...")
            sim = IsaacLabSim(device=args.device, viz=args.viz)
        else:
            print("[INFO] Using fast Kinematic Digital Twin simulation backend...")
            sim = KinematicSim(calib)

        try:
            # Run Mirroring Test
            data = run_mirroring_verification(
                hardware=hardware,
                sim=sim,
                calib=calib,
                test_mode=args.mode,
                num_random=args.waypoints,
                step_duration_s=args.step_time,
                rate_hz=30.0,
            )

            # Analyze Results
            report_joints = analyze_and_diagnose(data)
            print_diagnostic_report(report_joints)

            # Save Report JSON
            out_dir = Path(args.output_dir)
            out_dir.mkdir(parents=True, exist_ok=True)
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            report_file = out_dir / f"sim_real_mirror_report_{timestamp}.json"

            json_data = {
                "timestamp": timestamp,
                "sim_backend": args.sim,
                "mock": args.mock,
                "test_mode": args.mode,
                "summary": report_joints,
                "trace_sample": data["records"][::5],  # Sampled trace
            }
            with open(report_file, "w") as f:
                json.dump(json_data, f, indent=2)

            print(f"[SUCCESS] Complete diagnostic report saved to: {report_file}\n")

        finally:
            sim.close()

    finally:
        print("[INFO] Disabling motor torque and closing serial port...")
        hardware.close()


if __name__ == "__main__":
    main()

