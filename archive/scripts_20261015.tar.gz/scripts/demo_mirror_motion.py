#!/usr/bin/env python3
"""Interactive Sim-to-Real Motion Mirroring Demo.

Executes a smooth, deterministic reach-grasp-lift trajectory in Isaac Sim
and streams it at 60 Hz to the physical robot over UDP so you can watch
the virtual arm in Newton Viewer and the physical arm on your desk move together.
"""

from __future__ import annotations

import argparse
import math
import os
import signal
import sys
import time
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT_DIR / "src"))

from isaac_vision_rl.utils.calibration import JOINT_ORDER
from isaac_vision_rl.utils.hardware_client import HardwareStreamer


def interpolate(start_q: list[float], end_q: list[float], fraction: float) -> list[float]:
    """Smooth cosine interpolation between two joint poses."""
    alpha = 0.5 * (1.0 - math.cos(fraction * math.pi))
    return [(1.0 - alpha) * s + alpha * e for s, e in zip(start_q, end_q)]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--viz", choices=["newton", "kit", "none"], default="newton", help="Visualizer backend")
    parser.add_argument("--device", default="cuda:0", help="Simulation device")
    parser.add_argument("--udp-host", default="127.0.0.1", help="Hardware bridge host")
    parser.add_argument("--udp-port", type=int, default=9870, help="Hardware bridge port")
    parser.add_argument("--cycles", type=int, default=2, help="Number of demo cycles to execute")
    parser.add_argument("--sim-only", action="store_true", help="Run live simulation without opening a hardware UDP client")
    args = parser.parse_args()

    os.environ["SO101_POLICY"] = "rgb"
    os.environ["SO101_CURRICULUM"] = "fixed"
    os.environ["SO101_CUBE_JITTER"] = "0.0"
    os.environ["SO101_BOX_JITTER"] = "0.0"

    import gymnasium as gym
    import numpy as np
    import torch

    from isaaclab.app import launch_simulation
    from isaac_vision_rl.tasks.pickplace.config.so101.env_cfg import PickLiftEnvCfg
    from isaac_vision_rl.utils.grasp_geometry import ARM_NAMES, GraspGeometry

    cfg = PickLiftEnvCfg()
    cfg.scene.num_envs = 1
    cfg.sim.device = args.device

    print("\n" + "=" * 70)
    print("SO-101 Sim-to-Real Digital Twin Motion Mirroring Demo")
    print(f"Cycles:     {args.cycles}")
    print(f"Visualizer: {args.viz}")
    print(f"Hardware:   UDP {args.udp_host}:{args.udp_port} @ 60 Hz")
    print("=" * 70 + "\n")

    streamer = None if args.sim_only else HardwareStreamer(
        host=args.udp_host,
        port=args.udp_port,
        joint_names=JOINT_ORDER,
        target_rate_hz=60.0,
    )

    keep_running = True

    def sig_handler(sig, frame):
        nonlocal keep_running
        keep_running = False

    signal.signal(signal.SIGINT, sig_handler)
    signal.signal(signal.SIGTERM, sig_handler)

    viz_choice = None if args.viz == "none" else args.viz

    with launch_simulation(cfg, {"device": args.device, "visualizer": viz_choice}):
        env = gym.make("IsaacVisionRl-PickLift-SO101", cfg=cfg)
        try:
            env.reset()
            base = env.unwrapped
            robot = base.scene["robot"]
            cube = base.scene["cube"]

            joint_indices = [robot.find_joints(name)[0][0] for name in JOINT_ORDER]

            # Solve inverse kinematics for key waypoints
            spawner = cfg.scene.robot.spawn
            geometry = GraspGeometry(spawner.usd_path, cfg.scene.robot.init_state.pos, cfg.scene.robot.init_state.rot)
            cube_pos = np.array(cfg.scene.cube.init_state.pos)

            home_arm = [cfg.scene.robot.init_state.joint_pos[n] for n in ARM_NAMES]
            above_arm = geometry.solve(cube_pos + [0, 0, 0.05], home_arm).tolist()
            grasp_arm = geometry.solve(cube_pos, above_arm).tolist()
            lift_arm = geometry.solve(cube_pos + [0, 0, 0.08], grasp_arm).tolist()

            # Construct full 6-DoF poses: [5 arm joints, gripper]
            # gripper: 1.2 rad (open), 0.0 rad (closed)
            POSE_HOME = home_arm + [0.0]
            POSE_ABOVE = above_arm + [1.2]
            POSE_GRASP_OPEN = grasp_arm + [1.2]
            POSE_GRASP_CLOSED = grasp_arm + [0.0]
            POSE_LIFTED = lift_arm + [0.0]

            def execute_trajectory(start_pose: list[float], end_pose: list[float], duration_s: float, description: str):
                if not keep_running:
                    return
                print(f"  -> {description} ({duration_s:.1f}s)...")
                steps = max(1, int(duration_s / base.step_dt))
                for step_idx in range(steps):
                    if not keep_running:
                        break
                    frac = (step_idx + 1) / steps
                    target_q = interpolate(start_pose, end_pose, frac)

                    # Apply to simulated robot
                    q_tensor = robot.data.joint_pos.torch.clone()
                    q_tensor[0, joint_indices] = torch.tensor(target_q, device=args.device, dtype=torch.float32)
                    robot.set_joint_position_target(q_tensor)
                    for physics_step in range(cfg.decimation):
                        base.scene.write_data_to_sim()
                        base.sim.step(render=physics_step == cfg.decimation - 1)
                        base.scene.update(cfg.sim.dt)

                    # Extract current joint positions in radians
                    joint_pos_t = robot.data.joint_pos.torch[0, joint_indices]
                    joint_angles_rad = joint_pos_t.cpu().numpy().tolist()

                    # Stream to real robot hardware
                    if streamer is not None:
                        streamer.send_joint_targets(joint_angles_rad, is_reset=False)
                        streamer.pace(base.step_dt)
                    else:
                        time.sleep(base.step_dt)

            print("[INFO] Beginning mirroring demonstration across 60 Hz bridge...\n")
            current_pose = POSE_HOME

            for cycle in range(args.cycles):
                if not keep_running:
                    break
                print(f"[CYCLE {cycle + 1}/{args.cycles}]")

                execute_trajectory(current_pose, POSE_ABOVE, 3.0, "1. Approaching Pre-Grasp Pose (Opening Jaws)")
                execute_trajectory(POSE_ABOVE, POSE_GRASP_OPEN, 2.0, "2. Descending onto Cube")
                execute_trajectory(POSE_GRASP_OPEN, POSE_GRASP_CLOSED, 1.5, "3. Closing Gripper Fingers")
                execute_trajectory(POSE_GRASP_CLOSED, POSE_LIFTED, 2.5, "4. Lifting Cube Off Table")
                execute_trajectory(POSE_LIFTED, POSE_GRASP_CLOSED, 2.0, "5. Lowering Cube Back to Table")
                execute_trajectory(POSE_GRASP_CLOSED, POSE_GRASP_OPEN, 1.5, "6. Opening Gripper to Release")
                execute_trajectory(POSE_GRASP_OPEN, POSE_ABOVE, 1.5, "7. Retracting Clear of Cube")
                execute_trajectory(POSE_ABOVE, POSE_HOME, 2.5, "8. Returning to Home Stance")
                current_pose = POSE_HOME
                print()

        finally:
            print("[INFO] Demo finished. Safely parking hardware...")
            if streamer is not None:
                streamer.close()
            env.close()

    print("[SUCCESS] Mirroring demonstration complete.")


if __name__ == "__main__":
    main()

