#!/usr/bin/env python3
"""Interactive Wrist Roll Zero Alignment Tool for SO-101.

Disables torque on Motor 5 (wrist_roll) so you can physically align the gripper
straight with your hand, reads the exact encoder ticks, and updates the zero
point calibration so 0.0 rad in Isaac Sim matches physical straight orientation.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT_DIR / "src"))

# Try importing scservo_sdk
try:
    import scservo_sdk as scs
except ImportError:
    lerobot_pkg = Path("/home/ai/miniconda3/envs/lerobot/lib/python3.12/site-packages")
    if lerobot_pkg.exists() and str(lerobot_pkg) not in sys.path:
        sys.path.append(str(lerobot_pkg))
    import scservo_sdk as scs

from isaac_vision_rl.utils.calibration import CALIB_FILE_PATH, FollowerArmCalibration


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", default="/dev/ttyACM0", help="Serial port for Feetech servo bus")
    parser.add_argument("--baud", type=int, default=1_000_000, help="Baud rate (default 1,000,000)")
    parser.add_argument("--calib", default=CALIB_FILE_PATH, help="Path to calibration json")
    parser.add_argument("--set-ticks", type=int, default=None, help="Directly set zero ticks without interactive prompt")
    args = parser.parse_args()

    calib = FollowerArmCalibration(args.calib)
    wrist_id = calib.servo_ids[4]  # Motor 5

    print("\n" + "=" * 70)
    print("SO-101 WRIST ROLL (MOTOR 5) ZERO ALIGNMENT TOOL")
    print("=" * 70)

    ph = scs.PortHandler(args.port)
    pkh = scs.PacketHandler(0)

    if not ph.openPort():
        print(f"[ERROR] Could not open {args.port}")
        sys.exit(1)
    if not ph.setBaudRate(args.baud):
        print(f"[ERROR] Could not set baud rate {args.baud}")
        ph.closePort()
        sys.exit(1)

    try:
        # Read current pos
        pos_cur, comm, err = pkh.read2ByteTxRx(ph, wrist_id, 56)
        print(f"Current Motor 5 (wrist_roll) position: {pos_cur} ticks (Canonical midpoint is 2048)")

        if args.set_ticks is not None:
            measured_ticks = args.set_ticks
            print(f"[INFO] Using explicit target ticks: {measured_ticks}")
        else:
            # Disable torque on Motor 5
            pkh.write1ByteTxRx(ph, wrist_id, 40, 0)
            print("\n[ACTION REQUIRED]")
            print("  1. Torque on Motor 5 is now DISABLED.")
            print("  2. Physically hold / rotate the gripper with your hand so the jaws are")
            print("     oriented perfectly STRAIGHT / UPRIGHT (matching Isaac Sim).")
            print("  3. Press ENTER when the gripper is straight...")
            input()

            # Read back position
            measured_ticks, comm, err = pkh.read2ByteTxRx(ph, wrist_id, 56)

        delta_ticks = measured_ticks - 2048
        delta_deg = delta_ticks * 360.0 / 4096.0

        print("\n" + "-" * 70)
        print(f"Measured Straight Position: {measured_ticks} ticks")
        print(f"Displacement from 2048:     {delta_ticks:+d} ticks ({delta_deg:+.1f}°)")
        print("-" * 70)

        # Update my_awesome_follower_arm.json
        calib_path = Path(args.calib)
        with open(calib_path) as f:
            data = json.load(f)

        if "wrist_roll" in data:
            data["wrist_roll"]["zero_ticks"] = int(measured_ticks)
            with open(calib_path, "w") as f:
                json.dump(data, f, indent=4)
            print(f"[SUCCESS] Updated 'zero_ticks': {measured_ticks} in {calib_path.name}")

        # Test hold at verified position
        print("\n[VERIFICATION] Re-enabling torque at measured straight position...")
        pkh.write2ByteTxRx(ph, wrist_id, 42, measured_ticks)
        pkh.write1ByteTxRx(ph, wrist_id, 40, 1)
        time.sleep(1.0)
        final_pos, _, _ = pkh.read2ByteTxRx(ph, wrist_id, 56)
        print(f"[VERIFIED] Motor 5 is now holding steady at {final_pos} ticks.")
        print("Gripper is aligned with Isaac Sim!\n")

    finally:
        ph.closePort()


if __name__ == "__main__":
    main()

