#!/usr/bin/env python3
"""View the current RGB workcell; optional scripted 3-degree pan, not PPO."""
import argparse
import math
import os
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--headless", action="store_true")
    parser.add_argument("--seconds", type=float, default=300)
    parser.add_argument("--pan-demo", action="store_true")
    args = parser.parse_args()
    if args.seconds <= 0:
        parser.error("--seconds must be positive")
    os.environ["SO101_POLICY"] = "rgb"
    os.environ["SO101_CURRICULUM"] = "fixed"
    os.environ["SO101_CUBE_JITTER"] = "0"
    os.environ["SO101_BOX_JITTER"] = "0"
    import gymnasium as gym
    from isaaclab.app import launch_simulation
    from isaac_vision_rl.tasks.pickplace.config.so101.env_cfg import PickLiftEnvCfg

    cfg = PickLiftEnvCfg()
    cfg.scene.num_envs = 1
    cfg.sim.device = "cuda:0"
    cfg.sim.default_visualizer_cfg.background_color = (0.04, 0.06, 0.04)
    cfg.sim.default_visualizer_cfg.streaming_view = True
    cfg.sim.default_visualizer_cfg.streaming_envs = [0]
    with launch_simulation(cfg, {"device": "cuda:0", "visualizer": None if args.headless else "newton"}):
        env = gym.make("IsaacVisionRl-PickLift-SO101", cfg=cfg)
        try:
            env.reset()
            base = env.unwrapped
            robot = base.scene["robot"]
            home = robot.data.default_joint_pos
            home = home.torch if hasattr(home, "torch") else home
            home = home.clone()
            pan = robot.find_joints("shoulder_pan")[0][0]
            print("DEMO: home pose / scripted pan only; no trained policy", flush=True)
            start = time.monotonic()
            step = 0
            while time.monotonic() - start < args.seconds and not base.sim.is_stopped():
                tick = time.monotonic()
                target = home.clone()
                if args.pan_demo:
                    # Slow home -> +3 degrees -> home loop, measured in sim time.
                    phase = (step * cfg.sim.dt) % 8
                    fraction = min(1.0, max(0.0, (phase - 2) / 2)) if phase < 4 else max(0.0, (6 - phase) / 2)
                    target[:, pan] += math.radians(3) * fraction
                robot.set_joint_position_target(target)
                base.scene.write_data_to_sim()
                base.sim.step(render=step % cfg.decimation == 0)
                base.scene.update(cfg.sim.dt)
                step += 1
                time.sleep(max(0, cfg.sim.dt - (time.monotonic() - tick)))
        finally:
            env.close()


if __name__ == "__main__":
    main()
