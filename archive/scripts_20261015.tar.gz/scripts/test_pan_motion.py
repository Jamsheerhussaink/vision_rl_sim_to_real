#!/usr/bin/env python3
"""Compare a bounded relative shoulder-pan movement; this does not run PPO."""

import argparse
import json
import math
import os
import sys
import time
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))


def save_report(report):
    path = Path(report["report_path"])
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, indent=2) + "\n")
    print("REPORT:", path, flush=True)
    print(json.dumps({k: v for k, v in report.items() if k != "trace"}), flush=True)


def fraction(elapsed):
    if elapsed < 1:
        return 0.0
    if elapsed < 4:
        return (elapsed - 1) / 3
    if elapsed < 5:
        return 1.0
    if elapsed < 8:
        return (8 - elapsed) / 3
    return 0.0


def wait_for_start(args, mode):
    """Optional local ready/start barrier; never sends hardware instructions."""
    if not getattr(args, "start_file", None):
        return
    gate = Path(args.start_file)
    Path(str(gate) + f".{mode}.ready").write_text(json.dumps({"pid": os.getpid(), "mode": mode}))
    deadline = time.monotonic() + 120
    while not gate.exists():
        if time.monotonic() > deadline:
            raise RuntimeError("Timed out waiting for comparison start")
        time.sleep(.01)
    epoch = json.loads(gate.read_text())["start_epoch"]
    while time.time() < epoch:
        time.sleep(.005)


def real_test(args, report):
    import scservo_sdk as sdk

    calibration = json.loads((ROOT / "my_awesome_follower_arm.json").read_text())
    joints = ["shoulder_pan", "shoulder_lift", "elbow_flex", "wrist_flex", "wrist_roll", "gripper"]
    selected = getattr(args, "joint", "shoulder_pan")
    selected_index = joints.index(selected)
    joints[0], joints[selected_index] = joints[selected_index], joints[0]
    ids = [calibration[name]["id"] for name in joints]
    pan_id = ids[0]
    port = sdk.PortHandler(args.port)
    packet = sdk.PacketHandler(0)

    def read(motor, address, size=2):
        value, comm, error = (packet.read2ByteTxRx if size == 2 else packet.read1ByteTxRx)(port, motor, address)
        if comm != sdk.COMM_SUCCESS or error:
            raise RuntimeError(f"Read failed: motor {motor}, address {address}, communication {comm}, error {error}")
        return value

    def write(address, value, size=2):
        comm, error = (packet.write2ByteTxRx if size == 2 else packet.write1ByteTxRx)(port, pan_id, address, value)
        if comm != sdk.COMM_SUCCESS or error:
            raise RuntimeError(f"{selected} write failed: address {address}, communication {comm}, error {error}")

    opened = False
    original_torque = None
    enabled_by_test = False
    success = False
    try:
        if not port.openPort() or not port.setBaudRate(1000000):
            raise RuntimeError("Cannot open motor serial port")
        opened = True
        initial = [read(motor, 56) for motor in ids]
        original_torque = read(pan_id, 40, 1)
        if selected == "shoulder_lift" and original_torque != 1:
            raise RuntimeError("Shoulder lift must already be holding with torque enabled")
        if original_torque not in (0, 1):
            raise RuntimeError("Unexpected selected-joint torque state")
        if original_torque == 1 and abs(read(pan_id, 42) - initial[0]) > 5:
            raise RuntimeError("Selected joint is not holding close to its existing target")
        if any(read(motor, 33, 1) != 0 for motor in ids):
            raise RuntimeError("All motors must be in position mode")
        delta_ticks = round(args.degrees * 4095 / 360)
        lower, upper = calibration[joints[0]]["range_min"], calibration[joints[0]]["range_max"]
        if not lower + 34 <= initial[0] <= upper - 34 or not lower + 34 <= initial[0] + delta_ticks <= upper - 34:
            raise RuntimeError("Selected joint movement is too close to a calibrated limit")
        report.update(initial_ticks=dict(zip(joints, initial)), delta_ticks=delta_ticks,
                      requested_degrees=delta_ticks * 360 / 4095, initial_pan_torque=original_torque)
        report["joint"] = selected
        print(f"REAL: {selected} {initial[0]} -> {initial[0] + delta_ticks} -> {initial[0]} ticks; only motor {pan_id}", flush=True)
        write(42, initial[0])
        if read(pan_id, 42) != initial[0]:
            raise RuntimeError("Initial goal verification failed")
        enabled_by_test = True
        if original_torque == 0:
            write(40, 1, 1)
        if read(pan_id, 40, 1) != 1:
            raise RuntimeError("Selected-joint torque verification failed")
        wait_for_start(args, "real")
        start = time.monotonic()
        while time.monotonic() - start < 9:
            tick = time.monotonic()
            elapsed = tick - start
            measured = [read(motor, 56) for motor in ids]
            goal = initial[0] + round(delta_ticks * fraction(elapsed))
            if abs(measured[0] - goal) * 360 / 4095 > 1.5:
                raise RuntimeError(f"{selected} tracking error exceeded 1.5 degrees")
            if any(abs(measured[i] - initial[i]) * 360 / 4095 > 2 for i in range(1, 5)):
                raise RuntimeError("Another arm joint moved more than 2 degrees")
            if abs(measured[5] - initial[5]) > 22:
                raise RuntimeError("Unexpected gripper movement")
            write(42, goal)
            confirmed_goal = read(pan_id, 42)
            if confirmed_goal != goal:
                raise RuntimeError("Motor target readback differs from the sent target")
            report["trace"].append({"time_s": elapsed, "target_delta_deg": (goal - initial[0]) * 360 / 4095,
                                    "measured_delta_deg": (measured[0] - initial[0]) * 360 / 4095,
                                    "goal_readback_ticks": confirmed_goal,
                                    "selected_load_raw": read(pan_id, 60),
                                    "selected_voltage_raw": read(pan_id, 62, 1),
                                    "positions_ticks": measured})
            time.sleep(max(0, .05 - (time.monotonic() - tick)))
        endpoint = [r["measured_delta_deg"] for r in report["trace"] if 4.7 <= r["time_s"] < 5]
        final = [read(motor, 56) for motor in ids]
        report.update(endpoint_delta_deg=sum(endpoint) / len(endpoint),
                      return_error_deg=(final[0] - initial[0]) * 360 / 4095,
                      final_ticks=dict(zip(joints, final)))
        report["tracking_pass"] = abs(report["endpoint_delta_deg"] - report["requested_degrees"]) <= .5 and abs(report["return_error_deg"]) <= .5
        success = True
    finally:
        if opened:
            if enabled_by_test:
                # Preserve initial torque on success; stop pan torque on a fault.
                # On an error there is no automatic return movement.
                try:
                    if selected == "shoulder_lift":
                        if not success:
                            hold = read(pan_id, 56)
                            write(42, hold)
                            report["abort_hold_ticks"] = hold
                        # A load-bearing joint stays powered; never drop the arm.
                    else:
                        write(40, original_torque if success else 0, 1)
                    report["final_pan_torque"] = read(pan_id, 40, 1)
                    report["final_target_torque"] = report["final_pan_torque"]
                except Exception as error:
                    report["torque_restore_error"] = str(error)
                    print("Support the arm: could not confirm final holding state", flush=True)
                    success = False
            port.closePort()
        report["completed"] = success


def sim_test(args, report):
    os.environ["SO101_POLICY"] = "rgb"
    os.environ["SO101_CURRICULUM"] = "fixed"
    import gymnasium as gym
    from isaaclab.app import launch_simulation
    from isaac_vision_rl.tasks.pickplace.config.so101.env_cfg import PickLiftEnvCfg

    cfg = PickLiftEnvCfg()
    cfg.scene.num_envs = 1
    cfg.sim.device = "cuda:0"
    report["diagnostic_wrist_home"] = args.diagnostic_wrist_home
    if args.diagnostic_wrist_home is not None:
        cfg.scene.robot.init_state.joint_pos["wrist_flex"] = args.diagnostic_wrist_home
    report["diagnostic_no_collisions"] = args.diagnostic_no_collisions
    if args.diagnostic_no_collisions:
        cfg.scene.robot.spawn.collision_props.collision_enabled = False
    report["diagnostic_disabled_object"] = args.diagnostic_disable_object
    if args.diagnostic_disable_object:
        import copy
        item = getattr(cfg.scene, args.diagnostic_disable_object)
        item.spawn.collision_props = copy.deepcopy(cfg.scene.robot.spawn.collision_props)
        item.spawn.collision_props.collision_enabled = False
    with launch_simulation(cfg, {"device": "cuda:0", "visualizer": None if args.headless else "newton"}):
        env = gym.make("IsaacVisionRl-PickLift-SO101", cfg=cfg)
        try:
            env.reset()
            base = env.unwrapped
            robot = base.scene["robot"]
            pan = robot.find_joints(args.joint)[0][0]
            report["joint"] = args.joint
            home = robot.data.default_joint_pos.torch.clone()
            origin = float(home[0, pan])
            report["reference"] = "Simulation configured home; full real-to-sim pose mapping is unverified"
            report["joint_names"] = robot.joint_names
            report["pan_index"] = pan
            report["home_rad"] = home[0].cpu().tolist()
            report["backend"] = type(robot).__module__
            print(f"SIM: {args.degrees:+g} degree relative {args.joint} and return, {args.cycles} cycles; no PPO", flush=True)
            wait_for_start(args, "sim")
            step = 0
            while step * cfg.sim.dt < 9 * args.cycles:
                tick = time.monotonic()
                elapsed = step * cfg.sim.dt
                target = home.clone()
                delta = args.degrees * fraction(elapsed % 9)
                target[:, pan] += math.radians(delta)
                robot.actuators.target_command.set_position_index(value=target)
                base.scene.write_data_to_sim()
                base.sim.step(render=step % cfg.decimation == 0)
                base.scene.update(cfg.sim.dt)
                if step % 12 == 0:
                    report["trace"].append({"time_s": elapsed, "target_delta_deg": delta,
                                            "measured_delta_deg": math.degrees(float(robot.data.joint_pos.torch[0, pan]) - origin),
                                            "stored_target_delta_deg": math.degrees(float(robot.actuators.target_command.position.torch[0, pan]) - origin),
                                            "positions_rad": robot.data.joint_pos.torch[0].cpu().tolist(),
                                            "applied_torque_nm": robot.data.applied_torque.torch[0].cpu().tolist()})
                step += 1
                time.sleep(max(0, cfg.sim.dt - (time.monotonic() - tick)))
            endpoint = [r["measured_delta_deg"] for r in report["trace"] if 4.7 <= r["time_s"] < 5]
            report.update(completed=True, endpoint_delta_deg=sum(endpoint) / len(endpoint),
                          return_error_deg=report["trace"][-1]["measured_delta_deg"])
            report["tracking_pass"] = abs(report["endpoint_delta_deg"] - args.degrees) <= .5 and abs(report["return_error_deg"]) <= .5
            save_report(report)
            end = time.monotonic() + args.linger_seconds
            while time.monotonic() < end:
                tick = time.monotonic()
                robot.actuators.target_command.set_position_index(value=home)
                base.scene.write_data_to_sim()
                base.sim.step(render=step % cfg.decimation == 0)
                base.scene.update(cfg.sim.dt)
                step += 1
                time.sleep(max(0, cfg.sim.dt - (time.monotonic() - tick)))
        except (Exception, KeyboardInterrupt) as error:
            report["error"] = str(error) or type(error).__name__
            raise
        finally:
            # Kit shutdown can exit the process; persist measurements first.
            save_report(report)
            env.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", required=True, choices=["real", "sim"])
    parser.add_argument("--joint", choices=["shoulder_pan", "shoulder_lift"], default="shoulder_pan")
    parser.add_argument("--cycles", type=int, default=1, help="Number of simulation-only movement cycles")
    parser.add_argument("--start-file", help="Local start barrier for synchronized comparison")
    parser.add_argument("--linger-seconds", type=float, default=0, help="Keep simulator visible holding home after the movement")
    parser.add_argument("--degrees", type=float, default=2.0)
    parser.add_argument("--port", default="/dev/serial/by-id/usb-1a86_USB_Single_Serial_5B14031249-if00")
    parser.add_argument("--headless", action="store_true")
    parser.add_argument("--execute", action="store_true", help="Explicitly allow the bounded real pan test")
    parser.add_argument("--diagnostic-no-collisions", action="store_true", help="Simulation-only isolation test; disable robot collisions")
    parser.add_argument("--diagnostic-disable-object", choices=["table", "cube", "box"], help="Simulation-only contact isolation")
    parser.add_argument("--diagnostic-wrist-home", type=float, help="Simulation-only alternative reset wrist angle in radians")
    args = parser.parse_args()
    if args.cycles < 1 or (args.mode == "real" and args.cycles != 1):
        parser.error("Cycles must be positive; real tests allow only one cycle")
    maximum = 5 if args.joint == "shoulder_pan" else 2
    if not 0 < abs(args.degrees) <= maximum:
        parser.error(f"This joint allows only nonzero changes up to {maximum} degrees")
    if args.linger_seconds < 0:
        parser.error("Linger time cannot be negative")
    if args.mode == "real" and not args.execute:
        parser.error("Real movement requires --execute")
    if args.mode == "real" and (args.diagnostic_no_collisions or args.diagnostic_disable_object or args.diagnostic_wrist_home is not None):
        parser.error("Collision isolation is simulation-only")
    report = {"mode": args.mode, "requested_degrees": args.degrees, "policy_test": False,
              "completed": False, "trace": [],
              "report_path": str(ROOT / "outputs/hardware_mapping" / f"{args.joint}_{args.mode}_{datetime.now():%Y%m%d_%H%M%S}.json")}
    code = 0
    try:
        (real_test if args.mode == "real" else sim_test)(args, report)
        if not report["completed"]:
            code = 1
    except (Exception, KeyboardInterrupt) as error:
        report["error"] = str(error) or type(error).__name__
        print("Test aborted:", report["error"], flush=True)
        code = 1
    finally:
        save_report(report)
    return code


if __name__ == "__main__":
    raise SystemExit(main())
